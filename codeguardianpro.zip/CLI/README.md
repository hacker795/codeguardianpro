# stranarmy

stranarmy —— A powerful and useful tool for checking darkweb sites

# All Commands :

git clone https://github.com/hacker795/stranarmy/

cd stranarmy

bash run.sh


# Some Screenshots
![one3](https://user-images.githubusercontent.com/74674378/187064526-f5660bc6-b224-4305-aa49-318c3a890067.jpg)


# Start Tor Service


![one4](https://user-images.githubusercontent.com/74674378/187064550-3ce40752-9b2b-4333-9ae5-f7f8b46a5546.jpg)

# Use VPN

![one5](https://user-images.githubusercontent.com/74674378/187064582-0c17da0e-548b-451e-9ad6-7f1335ccd57f.jpg)


# Enter The Keyword

![one6](https://user-images.githubusercontent.com/74674378/187064618-c725d69a-a523-4803-9936-eae8f4cf13a4.jpg)


# Check Sites are active or Inactive

![one2](https://user-images.githubusercontent.com/74674378/187064663-2f1c7365-794f-47ba-bfe6-1e66a7f54818.jpg)

# Warning

This tool is only for educational purposes. If you use this tool for other purposes then my team is not responsible for that.

# THANKS TO :

:)



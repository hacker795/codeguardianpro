i = 0
for i in range(i):
	print(i)
username = "Test"
password = "password"
print(username, password)
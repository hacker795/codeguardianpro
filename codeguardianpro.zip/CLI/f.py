import pyttsx3
engine = pyttsx3.init()
engine.say("Please Choose your option!")
engine.runAndWait()
# RadiumX Tool 

This Tool help us Detect vulnerabilities in Sources code

1:Find The Phish Tool
2:Check Syntax Error
3:Check logical Error
4:Find SQL injection

# Terminal Output
Checking syntax error in source code
![](https://res.cloudinary.com/dtbikpook/image/upload/v1679464965/SyntaxErrorOutput_lxgwwh.png)
-----
Logical Error in Source Code
![enter image description here](https://res.cloudinary.com/dtbikpook/image/upload/v1679464962/logicalErrorOutput_jlrbaz.png)

Malicious URL Detector
![enter image description here](https://res.cloudinary.com/dtbikpook/image/upload/v1679464963/MaliciousURLDetectorOutput_yccef7.png)

# Vunerability Scanner Output
![enter image description here](https://res.cloudinary.com/dtbikpook/image/upload/v1679464964/Vunerability_Scanner_Output_pluuar.png)

### Output after Vunerability Check
![enter image description here](https://res.cloudinary.com/dtbikpook/image/upload/v1679464516/vunerabilityOutput_mayfeg.png)

---
## SQL Injection Found Output![enter image description here](https://res.cloudinary.com/dtbikpook/image/upload/v1679464962/SqlInjectionOutput_cwxp6m.png)

# Front End Web Output
![enter image description](https://res.cloudinary.com/dtbikpook/image/upload/v1679466085/MaliciousSourceCodeDetectorOutput_uweuqz.png)
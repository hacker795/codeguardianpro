apt-get update
apt-get install figlet
apt install python
apt install python2
apt install git
pkg install lolcat 
pip2 install lolcat
git clone https://github.com/xero/figlet-fonts
apt install tor
apt install openvpn
pip3 install onionsearch
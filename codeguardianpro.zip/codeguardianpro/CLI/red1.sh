clear
chafa -c full --color-space din99d --symbols -dot-stipple logo3.jpeg  